#!/usr/bin/env bash

echo "export PYTHONPATH=\$PYTHONPATH:$PWD" >>~/.bashrc